﻿namespace Fintech.Dominio.Entidades
{
    public enum TipoConta
    {
        ContaCorrente = 1,
        ContaEspecial = 2,
        Poupanca = 3
    }
}