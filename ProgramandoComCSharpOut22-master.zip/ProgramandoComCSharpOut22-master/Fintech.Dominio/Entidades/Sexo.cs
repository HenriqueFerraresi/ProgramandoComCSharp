﻿namespace Fintech.Dominio.Entidades
{
    public enum Sexo
    {
        Feminino = 1, 
        Masculino = 2,
        Outro = 3
    }
}