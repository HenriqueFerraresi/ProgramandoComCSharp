﻿namespace Fintech.Dominio.Entidades
{
    public enum TipoOperacao //: int
    {
        Deposito = 1,
        Saque = 2
    }
}