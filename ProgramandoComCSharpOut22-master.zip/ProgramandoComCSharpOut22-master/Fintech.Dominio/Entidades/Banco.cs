﻿namespace Fintech.Dominio.Entidades
{
    public class Banco
    {
        public int Id { get; set; }
        public int Numero { get; set; }
        public string Nome { get; set; }
    }
}